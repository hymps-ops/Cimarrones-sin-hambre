const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
const PORT = process.env.PORT || 3000;

app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true }));

const FOOD_BANK = [
  ["Huevo cocido","🥚","proteinas"],["Pollo","🍗","proteinas"],["Atún","🐟","proteinas"],
  ["Frijoles","🫘","proteinas"],["Queso panela","🧀","proteinas"],["Yogur natural","🥣","proteinas"],
  ["Manzana","🍎","frutas"],["Plátano","🍌","frutas"],["Mandarina","🍊","frutas"],
  ["Pera","🍐","frutas"],["Fresas","🍓","frutas"],["Uvas","🍇","frutas"],["Mango","🥭","frutas"],
  ["Zanahoria","🥕","verduras"],["Pepino","🥒","verduras"],["Jitomate","🍅","verduras"],
  ["Brócoli","🥦","verduras"],["Lechuga","🥬","verduras"],["Pimiento","🫑","verduras"],
  ["Calabacita","🥒","verduras"],["Aguacate","🥑","grasas"],["Nueces","🌰","grasas"],
  ["Cacahuates naturales","🥜","grasas"],["Semillas de calabaza","🎃","grasas"],
  ["Aceite de oliva","🫒","grasas"],["Tortilla de maíz","🌮","cereales"],["Pan integral","🍞","cereales"],
  ["Avena","🥣","cereales"],["Arroz","🍚","cereales"],["Tostadas horneadas","🥙","cereales"],
  ["Elote","🌽","cereales"],["Pasta","🍝","cereales"],
  ["Papas fritas","🍟","junk"],["Refresco","🥤","junk"],["Dulces","🍬","junk"],
  ["Galletas rellenas","🍪","junk"],["Pastelito empaquetado","🧁","junk"],["Gomitas","🍭","junk"],
  ["Bebida energética","🥫","junk"],["Nachos con queso","🧀","junk"],["Helado","🍦","junk"],
  ["Hamburguesa de comida rápida","🍔","junk"],["Dona glaseada","🍩","junk"],["Chocolate confitado","🍫","junk"]
];
const CATEGORIES = [
  {id:"proteinas", name:"Proteínas", emoji:"🥚"},
  {id:"frutas", name:"Frutas", emoji:"🍎"},
  {id:"verduras", name:"Verduras", emoji:"🥕"},
  {id:"grasas", name:"Grasas saludables", emoji:"🥑"},
  {id:"cereales", name:"Cereales", emoji:"🌽"}
];
const rooms = new Map();

function roomCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code;
  do { code = Array.from({length:5}, () => chars[Math.floor(Math.random()*chars.length)]).join(""); }
  while (rooms.has(code));
  return code;
}
function shuffled(a) {
  const out = [...a];
  for (let i=out.length-1; i>0; i--) {
    const j = Math.floor(Math.random()*(i+1));
    [out[i],out[j]] = [out[j],out[i]];
  }
  return out;
}
function publicPlayer(p) {
  return { id:p.id, name:p.name, connected:p.connected, finished:p.finished,
    finishMs:p.finishMs, filled:Object.keys(p.slots).length, slots:p.slots };
}
function emitRoom(room) {
  io.to(room.code).emit("room-state", {
    code: room.code, hostId: room.hostId, status: room.status,
    players: [...room.players.values()].map(publicPlayer),
    startAt: room.startAt, serverNow: Date.now()
  });
}
function playerDeck() {
  return shuffled(FOOD_BANK.map((f,i)=>({id:crypto.randomUUID(),name:f[0],emoji:f[1],type:f[2],revealed:false,used:false})));
}
function startRoom(room) {
  if (room.status !== "lobby" || room.players.size < 1) return;
  room.status = "countdown";
  room.startAt = Date.now() + 3500;
  room.players.forEach(p => {
    p.slots = {};
    p.deck = playerDeck();
    p.finished = false;
    p.finishMs = null;
    p.errors = 0;
    p.correct = 0;
    p.selectedCard = null;
  });
  emitRoom(room);
  io.to(room.code).emit("game-starting", {startAt: room.startAt, serverNow: Date.now()});
  setTimeout(() => {
    if (!rooms.has(room.code) || room.status !== "countdown") return;
    room.status = "playing";
    room.startedAt = Date.now();
    emitRoom(room);
    io.to(room.code).emit("game-begins", {startedAt: room.startedAt, serverNow: Date.now()});
  }, 3500);
}
function finishIfAll(room) {
  const active = [...room.players.values()].filter(p=>p.connected);
  if (active.length && active.every(p=>p.finished)) {
    room.status = "finished";
    emitRoom(room);
    io.to(room.code).emit("game-finished", {leaderboard: leaderboard(room)});
  }
}
function leaderboard(room) {
  return [...room.players.values()].map(p=>({
    id:p.id,name:p.name,finished:p.finished,finishMs:p.finishMs,
    filled:Object.keys(p.slots).length,connected:p.connected
  })).sort((a,b)=>{
    if (a.finished !== b.finished) return a.finished ? -1 : 1;
    if (a.finished && b.finished) return a.finishMs-b.finishMs;
    return b.filled-a.filled;
  });
}

io.on("connection", socket => {
  socket.on("create-room", ({name}, cb=()=>{}) => {
    name = String(name||"Jugador").trim().slice(0,24) || "Jugador";
    const code = roomCode();
    const player = {id:socket.id,name,connected:true,slots:{},deck:[],finished:false,finishMs:null,errors:0,correct:0,selectedCard:null};
    const room = {code,hostId:socket.id,players:new Map([[socket.id,player]]),status:"lobby",startAt:null,startedAt:null};
    rooms.set(code,room); socket.join(code); socket.data.room=code;
    cb({ok:true,code,playerId:socket.id}); emitRoom(room);
  });
  socket.on("join-room", ({code,name}, cb=()=>{}) => {
    code=String(code||"").trim().toUpperCase();
    name=String(name||"Jugador").trim().slice(0,24)||"Jugador";
    const room=rooms.get(code);
    if(!room) return cb({ok:false,error:"No encontramos esa sala. Revisa el código."});
    if(room.status!=="lobby") return cb({ok:false,error:"La partida ya comenzó. Pide al anfitrión crear otra sala."});
    if(room.players.size>=30) return cb({ok:false,error:"La sala ya tiene 30 participantes."});
    const player={id:socket.id,name,connected:true,slots:{},deck:[],finished:false,finishMs:null,errors:0,correct:0,selectedCard:null};
    room.players.set(socket.id,player);socket.join(code);socket.data.room=code;
    cb({ok:true,code,playerId:socket.id});emitRoom(room);
  });
  socket.on("start-game", (_data, cb=()=>{}) => {
    const room=rooms.get(socket.data.room);
    if(!room) return cb({ok:false,error:"Sala no encontrada."});
    if(room.hostId!==socket.id) return cb({ok:false,error:"Solo quien creó la sala puede iniciar."});
    if(room.status!=="lobby") return cb({ok:false,error:"La partida ya está en curso."});
    startRoom(room);cb({ok:true});
  });
  socket.on("reveal-card", ({cardId}, cb=()=>{}) => {
    const room=rooms.get(socket.data.room), p=room?.players.get(socket.id);
    if(!room||!p||room.status!=="playing"||p.finished) return cb({ok:false,error:"La partida no está activa."});
    if(p.selectedCard) return cb({ok:false,error:"Confirma tu carta actual primero."});
    const c=p.deck.find(x=>x.id===cardId);
    if(!c||c.used) return cb({ok:false,error:"Esa carta ya fue utilizada."});
    c.revealed=true;p.selectedCard=cardId;
    cb({ok:true,card:{id:c.id,name:c.name,emoji:c.emoji,type:c.type}});
  });
  socket.on("play-card", ({category}, cb=()=>{}) => {
    const room=rooms.get(socket.data.room), p=room?.players.get(socket.id);
    if(!room||!p||room.status!=="playing"||p.finished) return cb({ok:false,error:"La partida no está activa."});
    if(!p.selectedCard) return cb({ok:false,error:"Primero voltea una carta."});
    const c=p.deck.find(x=>x.id===p.selectedCard);
    if(!c||c.used) return cb({ok:false,error:"Carta inválida."});
    let message="", outcome="error";
    c.used=true;p.selectedCard=null;
    const occupied=Object.keys(p.slots);
    const loseOne=()=>{
      const keys=Object.keys(p.slots);
      if(!keys.length)return null;
      const key=keys[Math.floor(Math.random()*keys.length)];
      const lost=p.slots[key];delete p.slots[key];return lost;
    };
    if(c.type==="junk"){
      const lost=loseOne();p.errors++;
      message=lost?`¡Comida chatarra! Perdiste ${lost.emoji} ${lost.name}.`:"¡Comida chatarra! Aún no tienes alimentos que retirar.";
      outcome="junk";
    } else if(c.type===category && !p.slots[category]){
      p.slots[category]={id:c.id,name:c.name,emoji:c.emoji,type:c.type};
      p.correct++;message=`¡Correcto! ${c.name} va en ${CATEGORIES.find(g=>g.id===category)?.name||category}.`;outcome="correct";
    } else {
      const lost=loseOne();p.errors++;
      message=(c.type!==category?"Categoría incorrecta. ":"Ese espacio ya está ocupado. ")+(lost?`Perdiste ${lost.emoji} ${lost.name}.`:"Aún no tienes alimentos que retirar.");
    }
    if(Object.keys(p.slots).length===CATEGORIES.length){
      p.finished=true;p.finishMs=Date.now()-room.startedAt;
      outcome="finished";message="¡Lonchera completa! Terminaste en "+(p.finishMs/1000).toFixed(2)+" segundos.";
    }
    cb({ok:true,outcome,message,card:{id:c.id,name:c.name,emoji:c.emoji,type:c.type,used:true},slots:p.slots,finished:p.finished,finishMs:p.finishMs,serverNow:Date.now()});
    socket.emit("my-deck", {deck:p.deck.map(x=>({id:x.id,name:x.name,emoji:x.emoji,revealed:x.revealed,used:x.used}))});
    emitRoom(room);
    if(p.finished) io.to(room.code).emit("leaderboard-update",{leaderboard:leaderboard(room)});
    finishIfAll(room);
  });
  socket.on("request-my-deck", (_data, cb=()=>{}) => {
    const room=rooms.get(socket.data.room),p=room?.players.get(socket.id);
    if(!p) return cb({ok:false});
    cb({ok:true,deck:p.deck.map(x=>({id:x.id,name:x.name,emoji:x.emoji,revealed:x.revealed,used:x.used}))});
  });
  socket.on("disconnect",()=>{
    const room=rooms.get(socket.data.room);if(!room)return;
    const p=room.players.get(socket.id);
    if(p){p.connected=false;emitRoom(room);}
    if(room.players.size===0)rooms.delete(room.code);
  });
});
server.listen(PORT,()=>console.log(`Arma tu lonche saludable en http://localhost:${PORT}`));
