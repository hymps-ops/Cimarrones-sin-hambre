# Arma tu lonche saludable — versión multijugador

Esta es una aplicación web multijugador para 10–30 participantes. Incluye:
- Salas con código de 5 caracteres.
- Inicio sincronizado para todos los jugadores.
- Agua fija en cada lonchera; no aparece en las cartas.
- Baraja aleatoria individual para cada participante.
- Penalizaciones por clasificar mal o sacar comida chatarra.
- Cronómetro y clasificación ordenada por tiempo de finalización.
- El servidor valida las jugadas y registra los tiempos.

## Importante
El archivo no es por sí solo un servidor público. Para que alumnos entren desde sus propios dispositivos por internet, hay que desplegarlo en un proveedor que admita Node.js y WebSockets (Socket.IO), por ejemplo Render, Railway o un VPS. No he publicado la aplicación en internet ni creado una URL pública desde este entorno.

## Probar en tu computadora
Necesitas instalar Node.js 18 o posterior.

1. Descomprime la carpeta.
2. Abre una terminal dentro de la carpeta `arma_lonche_multijugador`.
3. Ejecuta:

   ```bash
   npm install
   npm start
   ```

4. Abre `http://localhost:3000`.

Para probar desde otro dispositivo en la misma Wi-Fi, abre la dirección IP local de la computadora que ejecuta el servidor, por ejemplo `http://192.168.1.25:3000` (la IP real depende de tu red y hay que permitir el acceso en el firewall).

## Publicarla para jugar por internet
1. Crea una cuenta en un servicio de alojamiento que soporte aplicaciones Node.js y WebSockets.
2. Sube esta carpeta a un repositorio Git o usa la opción de despliegue desde archivos si el proveedor la admite.
3. Configura el comando de inicio como `npm start`. El proveedor debe asignar `PORT` automáticamente.
4. Abre la URL HTTPS pública que te entregue el proveedor y compártela con los jugadores.

Los planes gratuitos y sus límites cambian según el proveedor. Revisa las condiciones actuales antes de elegir uno.

## Cómo se juega
1. Una persona crea la sala y comparte el código.
2. Los demás entran con su nombre y el código.
3. El anfitrión presiona **Iniciar para todos**.
4. Cada participante completa proteínas, frutas, verduras, grasas saludables y cereales; el agua ya está incluida.
5. El servidor registra el tiempo cuando se completan correctamente los cinco grupos.
6. Al finalizar, se muestra la clasificación. Los jugadores que no terminen aparecen después de quienes sí completaron.

## Notas para una versión de uso público
Esta versión es un prototipo inicial. Para eventos importantes conviene añadir reconexión de jugadores, reinicio de partidas desde el anfitrión, límites contra abuso y persistencia de resultados. La clasificación vive en memoria y se borra si el servidor se reinicia. El servidor mantiene las cartas de cada jugador; los clientes solo reciben su propia baraja.
